﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPF.MDI;

namespace MDIApplication
{
    /// <summary>
    /// Interaction logic for MainWindow2.xaml
    /// </summary>
    public partial class MainWindow2 : Window
    {
        public MainWindow2()
        {
            InitializeComponent();
        }
        private void submenuCustomer_Click(object sender, RoutedEventArgs e)
        {
            MainMdiContainer.Children.Add(new MdiChild()
            {
                Title = " Child Window",
                Height = 750,
                Width = 750,
                //Here CustomerMaster is the class that you have created for mainWindow.xaml user control.
                Content = new CustomerMaster()
            });
        }
        private void submenuHome_Click(object sender, RoutedEventArgs e)
        {
            MainMdiContainer.Children.Add(new MdiChild()
            {
                Title = "Home Window",
                Height = 750,
                Width = 750,
                //Here CustomerMaster is the class that you have created for mainWindow.xaml user control.
                Content = new HomeUserControl()
            });
        } 
    }
}
